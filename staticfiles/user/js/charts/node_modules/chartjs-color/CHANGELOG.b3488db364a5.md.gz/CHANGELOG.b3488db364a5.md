# 0.11.1 - 2016-01-03

- Fixed: three tests being ignored `if() -> it()`
- Changed: moved to XO standard

# 0.11.0 - 2016-01-02

- Fixed: Hue modulo when specifying values < 0 or > 360
([#76](https://github.com/MoOx/color/pull/76))
- Corrected some package.json information

# 0.10.1 - 2015-07-02

- Fixed: handling of 0% mix
([#65](https://github.com/harthur/color/pull/65))

# 0.10.0 - 2015-07-02

- Fixed: `mix()` works with a 0..1 range (instead of 0..100 since 0.9.0)
([#64](https://github.com/harthur/color/pull/64))

# 0.9.0 - 2015-06-21

- Fixed: `mix()` implementation is now the same as in Sass
([#60](https://github.com/harthur/color/pull/60))

# 0.8.0 - 2015-03-03

- Removed: bower support
- Removed: component(1) support
- Changed: Upgrade to color-string 0.3

---

Check out commit logs for older releases
